import 'package:hive_flutter/adapters.dart';

import '../Modal/Data_modal.dart';

Future<void> createAccount(AccountModal value) async {
  final accountsDatabase = await Hive.openBox<AccountModal>('accounts_db');
  final _id = await accountsDatabase.add(value);
  value.id =_id;
}

Future getAccount(String number) async {
  List<AccountModal> accountList = [];
  final accountsDatabase = await Hive.openBox<AccountModal>('accounts_db');

  accountList.addAll(accountsDatabase.values);
  List<AccountModal> accountListNew =
      accountList.where((item) => item.mobileNumber == number).toList();
  return accountListNew;
}
Future updateAccount(int id,value)async{
  final accounts = await Hive.openBox<AccountModal>('accounts_db');
  print(id);
  print(value);
  await accounts.put(id, value);
  print(id);


}



