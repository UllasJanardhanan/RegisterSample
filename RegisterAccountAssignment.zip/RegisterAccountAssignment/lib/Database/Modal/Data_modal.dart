import 'package:hive_flutter/adapters.dart';
part 'Data_modal.g.dart';
@HiveType(typeId: 1)
class AccountModal extends HiveObject {
  @HiveField(0)
  int? id;
  @HiveField(1)
  final String firstName;
  @HiveField(2)
  final String lastName;
  @HiveField(3)
  final String email;
  @HiveField(4)
  final String mobileNumber;
  @HiveField(5)
  final String dateOfBirth;

  AccountModal( {
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.mobileNumber,
    required this.dateOfBirth,
    this.id,
  });
}
