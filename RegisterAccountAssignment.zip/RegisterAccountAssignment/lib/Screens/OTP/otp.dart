import 'package:flutter/material.dart';
import 'package:register/Screens/Dashboard/Dashboard.dart';

import '../../Database/Functions/functions.dart';
import '../../Database/Modal/Data_modal.dart';
import '../Login/login.dart';

import '../Profile/profile.dart';

class OtpPage extends StatelessWidget {
  final otpCreated;
  final mobileNumber;
  const OtpPage(
      {Key? key, required this.otpCreated, required this.mobileNumber})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _otpController = TextEditingController();
    // var heightIs = MediaQuery.of(context).size.height;
    // var widthIs = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(30.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    'You will get a OTP via SMS ',
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.black54),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 15.0, bottom: 23),
                  child: TextFormField(
                    obscureText: true,
                    controller: _otpController,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      // prefixIcon: Icon(Icons.phone_android),
                      hintText: 'Code you received',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(20.0),
                        ),
                        borderSide: BorderSide(
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.all(Colors.white),
                      backgroundColor: MaterialStateProperty.all(Colors.green),
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                    ),
                    onPressed: () async {
                      final otpText = _otpController.text;
                      List<AccountModal> accountListFinal =
                          await getAccount(mobileNumber);
                      final length = accountListFinal.length;
                      print("Otp is $otpCreated");

                      if (otpText == "$otpCreated") {
                        if (length == 0) {
                          // profile creation
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Profile(
                                mobileNumber: mobileNumber,
                              ),
                            ),
                          );
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DashBoard(
                                mobileNumber: mobileNumber,
                              ),
                            ),
                          );
                        }
                      } else {
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text("Invalid OTP"),
                                content: Text('Entered otp is $otpText'),
                                actions: [
                                  TextButton(
                                    child: const Text("Resend OTP"),
                                    onPressed: () {
                                      Navigator.of(context).pushAndRemoveUntil(
                                          MaterialPageRoute(
                                              builder: (c) => const Login()),
                                          (route) => false);
                                    },
                                  ),
                                  TextButton(
                                    child: const Text("Ok"),
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                  )
                                ],
                              );
                            });
                      }
                    },
                    child: const Text('Verify'),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
