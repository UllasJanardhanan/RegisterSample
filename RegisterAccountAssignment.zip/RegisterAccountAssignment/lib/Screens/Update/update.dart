import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:register/Database/Functions/functions.dart';

import '../../Database/Modal/Data_modal.dart';
import '../Dashboard/Dashboard.dart';

class Update extends StatefulWidget {
  final mobileNumber;
  const Update({Key? key, required this.mobileNumber}) : super(key: key);

  @override
  State<Update> createState() => _UpdateState();
}

class _UpdateState extends State<Update> {
  List<AccountModal> accountUpdate = [];
  final formKey = GlobalKey<FormState>();
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  String firstName = "";
  String lastName = "";
  String eMail = "";
  String mobileNumber = "";
  String dateOfBirth = "";

  @override
  void dispose() {
    _emailController.dispose();
    _lastNameController.dispose();
    _firstNameController.dispose();

    super.dispose();
  }

  DateTime? myDate;
  String time = "Select your date of birth";
  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance!.addPostFrameCallback((_) async {
      accountUpdate = await getAccount(widget.mobileNumber);

      _firstNameController.text = accountUpdate[0].firstName;
      _lastNameController.text = accountUpdate[0].lastName;
      _emailController.text = accountUpdate[0].email;
      time = accountUpdate[0].dateOfBirth;
    });

    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: SafeArea(
          child: Padding(
              padding: const EdgeInsets.all(30.0),
              child: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      const Text(
                        'Update your details',
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.black54),
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                      TextFormField(
                        controller: _firstNameController,
                        keyboardType: TextInputType.text,
                        // initialValue: "firstName",
                        validator: (fname) {
                          if (fname!.isEmpty ||
                              !RegExp(r'^[a-zA-Z]+$').hasMatch(fname)) {
                            return "Enter correct name";
                          } else {
                            return null;
                          }
                        },
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.person),
                          hintText: 'First Name',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(20.0),
                            ),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        controller: _lastNameController,
                        keyboardType: TextInputType.text,
                        // initialValue: "lastName",
                        validator: (lname) {
                          if (lname!.isEmpty ||
                              !RegExp(r'^[a-zA-Z]+$').hasMatch(lname)) {
                            return "Enter correct name";
                          } else {
                            return null;
                          }
                        },
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.person),
                          hintText: 'Last Name',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(20.0),
                            ),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        // autofillHints:  [AutofillHints.email],
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        validator: (email) =>
                            email != null && !EmailValidator.validate(email)
                                ? "Enter a valid email"
                                : null,
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.mail),
                          hintText: 'Email',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(20.0),
                            ),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 55,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black38),
                            borderRadius: BorderRadius.circular(20)),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const Icon(
                                Icons.phone_android,
                                size: 25,
                                color: Colors.blueGrey,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                widget.mobileNumber,
                                style: const TextStyle(
                                    fontSize: 20, color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black38),
                            borderRadius: BorderRadius.circular(20)),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 30, right: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                time,
                                style: const TextStyle(
                                    fontSize: 20, color: Colors.black),
                              ),
                              IconButton(
                                  onPressed: () async {
                                    myDate = await showDatePicker(
                                        context: context,
                                        initialDate: DateTime.now(),
                                        firstDate: DateTime(1950),
                                        lastDate: DateTime.now());
                                    setState(() {
                                      time = DateFormat('dd-MM-yy')
                                          .format(myDate!);
                                    });
                                  },
                                  icon: const Icon(
                                    Icons.calendar_month,
                                    size: 20,
                                  )),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            foregroundColor:
                                MaterialStateProperty.all(Colors.white),
                            backgroundColor:
                                MaterialStateProperty.all(Colors.green),
                            shape: MaterialStateProperty.all(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                          ),
                          onPressed: () {
                            final form = formKey.currentState!;

                            if (form.validate()) {
                              final email = _emailController.text;
                              final firstName = _firstNameController.text;
                              final lastName = _lastNameController.text;

                              final _data = AccountModal(
                                  firstName: firstName,
                                  lastName: lastName,
                                  email: email,
                                  mobileNumber: widget.mobileNumber,
                                  dateOfBirth: time);
                              int? id = accountUpdate[0].id;
                              if (id != null) {
                                updateAccount(id, _data);
                              }
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DashBoard(
                                    mobileNumber: widget.mobileNumber,
                                  ),
                                ),
                              );
                            }
                          },
                          child: const Text('Update'),
                        ),
                      )
                    ],
                  ),
                ),
              )),
        ),
      ),
    );
  }
}
