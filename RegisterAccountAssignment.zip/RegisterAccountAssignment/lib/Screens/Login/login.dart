import 'package:flutter/material.dart';

import '../OTP/otp.dart';
import 'package:otp/otp.dart';
import 'package:flutter_sms/flutter_sms.dart';
import 'package:telephony/telephony.dart';


class Login extends StatelessWidget {
  const Login({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    final Telephony telephony = Telephony.instance;
    final formKey = GlobalKey<FormState>();
    final _mobileNumber = TextEditingController();
    List<String> recipients = [];
    String message = '';
    return Scaffold(

      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(30.0),
            child: Form(
              key:formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text(
                      'Please login',
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          color: Colors.black54),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 15.0, bottom: 23),
                    child: TextFormField(
                      controller: _mobileNumber,
                      keyboardType: TextInputType.number,
                      validator: (mob) {
                        if (mob!.isEmpty ||
                            !RegExp(r'^(?:[+0]9)?[0-9]{10}$').hasMatch(mob)) {
                          return "Enter correct mobile number";
                        }else{
                          return null;
                        }
                      },
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.phone_android),
                        hintText: 'Mobile number',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(20.0),
                          ),
                          borderSide: BorderSide(
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ButtonStyle(
                        foregroundColor: MaterialStateProperty.all(Colors.white),
                        backgroundColor: MaterialStateProperty.all(Colors.green),
                        shape: MaterialStateProperty.all(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                      ),
                      onPressed: () async {
                        final form = formKey.currentState!;
                        if(form.validate()){
                          final otpCreated = otp();
                          print(otpCreated);
                          final mobileNumber = _mobileNumber.text;
                          message = "Otp for login is : $otpCreated!";
                          recipients = [mobileNumber];
                         await telephony.sendSms(to: mobileNumber, message: message);
                          // _sendSMS(message, recipients);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => OtpPage(
                                otpCreated: otpCreated,
                                mobileNumber: mobileNumber,
                              ),
                            ),
                          );
                        }
                      },
                      child: const Text('Get OTP'),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

otp() {
  final code = OTP.generateTOTPCode(
      'JBSWY3DPEHPK3PXP', DateTime.now().millisecondsSinceEpoch,
      length: 5);
  return code;
}

