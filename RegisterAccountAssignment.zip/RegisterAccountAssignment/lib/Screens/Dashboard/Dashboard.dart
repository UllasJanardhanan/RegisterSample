import 'package:flutter/material.dart';
import 'package:register/Database/Functions/functions.dart';
import 'package:register/Screens/Update/update.dart';

import '../../Database/Modal/Data_modal.dart';
import '../Login/login.dart';

class DashBoard extends StatefulWidget {
  final mobileNumber;
  const DashBoard({Key? key, required this.mobileNumber}) : super(key: key);

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  List<AccountModal> accountFinal = [];
  String firstName = "";
  String lastName = "";
  String eMail = "";
  String mobileNumber = "";
  String dateOfBirth = "";
  var scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance!.addPostFrameCallback((_) async {
      accountFinal = await getAccount(widget.mobileNumber);
      setState(() {
        firstName = accountFinal[0].firstName;
        lastName = accountFinal[0].lastName;
        eMail = accountFinal[0].email;
        mobileNumber = accountFinal[0].mobileNumber;
        dateOfBirth = accountFinal[0].dateOfBirth;
      });
    // getAccount();
    // var heightIs = MediaQuery.of(context).size.height;
    // var widthIs = MediaQuery.of(context).size.width;
    // print(accountList[0].email);
      });
    return Scaffold(
      key: scaffoldKey,
      endDrawer: Drawer(
        child: Padding(
          padding: const EdgeInsets.only(top: 60.0, left: 10, right: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15, right: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Profile',
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          color: Colors.black54),
                    ),
                    IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Update(
                                mobileNumber: mobileNumber,
                              ),
                            ),
                          );
                          //Edit page
                        },
                        icon: const Icon(
                          Icons.edit,
                          color: Colors.green,
                        ))
                  ],
                ),
              ),
              Text(
                '$firstName $lastName',
                style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.black54),
              ),
              const SizedBox(
                height: 20,
              ),
              Text(
                eMail,
                style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.black54),
              ),
              const SizedBox(
                height: 20,
              ),
              Text(
                mobileNumber,
                style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.black54),
              ),
              const SizedBox(
                height: 20,
              ),
              Text(
                dateOfBirth,
                style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.black54),
              ),
              const SizedBox(
                height: 20,
              ),
              Center(
                child: ElevatedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.green),
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                    ),
                    onPressed: () {
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (c) => const Login()),
                          (route) => false);
                    },
                    child: const Text(
                      'Log out',
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    )),
              )
            ],
          ),
        ),
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15.0, right: 15.0),
                child: Row(
                  children: [
                    const Text('Dashboard',
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.black54)),
                    const Spacer(),
                    IconButton(
                      onPressed: () async {
                        scaffoldKey.currentState!.openEndDrawer();
                        // accountFinal = await getAccount(widget.mobileNumber);

                      },
                      icon: const Icon(
                        Icons.person_pin,
                        size: 35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
